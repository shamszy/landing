<?php

namespace App\Libs\Enums;

enum RoleEnum: string
{
    case COMPANY= 'company';
    case ADMIN = 'admin';
}
