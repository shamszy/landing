<template>
    <div class="bg-white">
        <!-- Header -->
            <Header />
        <!-- End of Header -->

        <main class="isolate">
            <!-- Hero section -->
            <section class="mb-40 space-y-[5px]">
              
  <!-- SVG Background -->
  <span class="[&>svg]:absolute [&>svg]:-z-10 [&>svg]:hidden [&>svg]:h-[560px] [&>svg]:w-full [&>svg]:lg:block">
    <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" preserveAspectRatio="none"
      class="absolute top-[60px] hidden h-[580px] w-full transition-opacity duration-300 dark:opacity-0 lg:block">
      <defs>
        <linearGradient id="sw-gradient-light" x1="0" x2="0" y1="1" y2="0">
          <stop stop-color="hsl(209, 92.2%, 92.1%)" offset="0%"></stop>
          <stop stop-color="hsl(209, 92.2%, 99.1%)" offset="100%"></stop>
        </linearGradient>
      </defs>
      <path fill="url(#sw-gradient-light)"
        d="M -0.664 3.46 C -0.664 3.46 405.288 15.475 461.728 21.285 C 601.037 35.625 672.268 76.086 701.056 97.646 C 756.056 138.838 797.267 216.257 857.745 245.156 C 885.704 258.516 980.334 280.547 1048.511 268.826 C 1121.622 256.256 1199.864 226.267 1214.176 220.176 C 1241.273 208.643 1280.201 191.509 1343.494 179.436 C 1434.325 162.111 1439.504 196.099 1439.503 183.204 C 1439.502 161.288 1440 0 1440 0 L 1360 0 C 1280 0 1120 0 960 0 C 800 0 640 0 480 0 C 320 0 160 0 80 0 L 0 0 L -0.664 3.46 Z">
      </path>
    </svg>
    <svg data-name="Layer 2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" preserveAspectRatio="none"
      class="absolute top-[60px] hidden h-[580px] w-full opacity-0 transition-opacity duration-300 dark:opacity-100 lg:block">
      <defs>
        <linearGradient id="sw-gradient-dark" x1="0" x2="0" y1="1" y2="0">
          <stop stop-color="hsl(240, 4%, 28%)" offset="0%"></stop>
          <stop stop-color="hsl(0, 0%, 15%)" offset="100%"></stop>
        </linearGradient>
      </defs>
      <path fill="url(#sw-gradient-dark)"
        d="M -0.664 3.46 C -0.664 3.46 405.288 15.475 461.728 21.285 C 601.037 35.625 672.268 76.086 701.056 97.646 C 756.056 138.838 797.267 216.257 857.745 245.156 C 885.704 258.516 980.334 280.547 1048.511 268.826 C 1121.622 256.256 1199.864 226.267 1214.176 220.176 C 1241.273 208.643 1280.201 191.509 1343.494 179.436 C 1434.325 162.111 1439.504 196.099 1439.503 183.204 C 1439.502 161.288 1440 0 1440 0 L 1360 0 C 1280 0 1120 0 960 0 C 800 0 640 0 480 0 C 320 0 160 0 80 0 L 0 0 L -0.664 3.46 Z">
      </path>
    </svg>
  </span>
  <!-- SVG Background -->

  <!-- Jumbotron -->
  <div class="px-6 py-12 text-center md:px-12 lg:my-12 lg:text-left">
    <div class="w-100 mx-auto sm:max-w-2xl md:max-w-3xl lg:max-w-5xl xl:max-w-7xl">
      <div class="grid items-center gap-12 lg:grid-cols-2">
        <div class="mt-12 lg:mt-0">
          <h2 class="mb-16 text-4xl font-bold tracking-tight md:text-5xl xl:text-6xl">
            Empowering Nigeria's <br /><span class="text-primary">Solid Mineral Sector:</span>
          </h2>
          <h4
                        class="py-3 pl-2 mb-4 text-2xl font-bold text-gray-700 border-l-4 border-green-500 dark:border-green-400 dark:text-gray-300">
                        MIREMCO, Catalyst for Tripartite Government Collaboration - Fueling Progress through Unity in Mineral Development.
                    </h4>
          
          <a class="mb-2 inline-block rounded bg-primary px-12 pt-4 pb-3.5 text-sm font-medium uppercase leading-normal text-black shadow-[0_4px_9px_-4px_#3b71ca] transition duration-150 ease-in-out hover:bg-primary-600 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] md:mr-2 md:mb-0"
            data-te-ripple-init data-te-ripple-color="light" href="/register" role="button">Get started</a>
            <p></p>
        </div>
        <div class="mb-12 lg:mb-0">
          <img src="https://netstorage-legit.akamaized.net/images/41b36fd13ceffb22.jpg?imwidth=1200"
            class="w-full rounded-lg shadow-lg dark:shadow-black/20" alt="" />
        </div>
      </div>
    </div>
  </div>
  <!-- Jumbotron -->
</section>
<section class="flex items-center bg-stone-100 xl:h-screen font-poppins dark:bg-gray-800 space-y-[1px]">
        <div class="justify-center flex-1 max-w-6xl py-4 mx-auto lg:py-6 md:px-6">
            <div class="px-4 mb-10 md:text-center md:mb-20">
              
                <p class="mb-2 text-lg font-semibold text-green-500 dark:text-gray-400 my-8">
                    About
                </p>
                <h2 class="pb-2 text-2xl font-bold text-gray-800 md:text-4xl dark:text-gray-300">
                    MIREMCO
                </h2>
                <div class="flex w-32 mt-1 mb-6 overflow-hidden rounded md:mx-auto md:mb-14">
                    <div class="flex-1 h-2 bg-green-200">
                    </div>
                    <div class="flex-1 h-2 bg-green-400">
                    </div>
                    <div class="flex-1 h-2 bg-green-300">
                    </div>
                </div>
            </div>
            <div class="flex flex-wrap ">
                <div class="w-full px-4 mb-10 lg:w-1/2 lg:mb-0">
                    <img src="https://cdn.vanguardngr.com/wp-content/uploads/2022/03/Mining-site.jpg" alt=""
                        class="relative z-40 object-cover w-full h-96">
                </div>
                <div class="w-full px-4 mb-10 lg:w-1/2 lg:mb-0 ">
                    
                    <p class="mb-4 text-base leading-7 text-gray-500 dark:text-gray-400">
                        MIREMCO was established by Section 19 (1) of the Nigerian Minerals and Mining Act, 2007 in order to create a synergy between the 3 tiers of government (Federal, State & Local Govt) which is a major factor in the development of solid mineral resources in Nigeria.
                    </p>
                    <h2
                        class="py-3 pl-2 mb-4 text-2xl font-bold text-gray-700 border-l-4 border-green-500 dark:border-blue-400 dark:text-gray-300">
                        The Committee's Objectives
                    </h2>
                    <ul class="mb-10">
                        <li class="flex items-center mb-4 text-base text-gray-600 dark:text-gray-400">
                            <span class="mr-3 text-blue-500 dark:text-blue-400 ">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green"
                                    class="w-5 h-5 bi bi-patch-check-fill" viewBox="0 0 16 16">
                                    <path
                                        d="M10.067.87a2.89 2.89 0 0 0-4.134 0l-.622.638-.89-.011a2.89 2.89 0 0 0-2.924 2.924l.01.89-.636.622a2.89 2.89 0 0 0 0 4.134l.637.622-.011.89a2.89 2.89 0 0 0 2.924 2.924l.89-.01.622.636a2.89 2.89 0 0 0 4.134 0l.622-.637.89.011a2.89 2.89 0 0 0 2.924-2.924l-.01-.89.636-.622a2.89 2.89 0 0 0 0-4.134l-.637-.622.011-.89a2.89 2.89 0 0 0-2.924-2.924l-.89.01-.622-.636zm.287 5.984-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.793l2.646-2.647a.5.5 0 0 1 .708.708z" />
                                </svg>
                            </span>
                            To serve as an interface between the Federal Ministry, State, Local Government, Mineral Title Holders and Host Communities.
                        </li>
                        <li class="flex items-center mb-4 text-base text-gray-600 dark:text-gray-400">
                            <span class="mr-3 text-blue-500 dark:text-blue-400">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green"
                                    class="w-5 h-5 bi bi-patch-check-fill" viewBox="0 0 16 16">
                                    <path
                                        d="M10.067.87a2.89 2.89 0 0 0-4.134 0l-.622.638-.89-.011a2.89 2.89 0 0 0-2.924 2.924l.01.89-.636.622a2.89 2.89 0 0 0 0 4.134l.637.622-.011.89a2.89 2.89 0 0 0 2.924 2.924l.89-.01.622.636a2.89 2.89 0 0 0 4.134 0l.622-.637.89.011a2.89 2.89 0 0 0 2.924-2.924l-.01-.89.636-.622a2.89 2.89 0 0 0 0-4.134l-.637-.622.011-.89a2.89 2.89 0 0 0-2.924-2.924l-.89.01-.622-.636zm.287 5.984-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.793l2.646-2.647a.5.5 0 0 1 .708.708z" />
                                </svg>
                            </span>
                            To ensure development and exploitation of mineral resources in a sustainable & orderly manner.
                        </li>
                        <li class="flex items-center mb-4 text-base text-gray-600 dark:text-gray-400">
                            <span class="mr-3 text-blue-500 dark:text-blue-400 ">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="green"
                                    class="w-5 h-5 bi bi-patch-check-fill" viewBox="0 0 16 16">
                                    <path
                                        d="M10.067.87a2.89 2.89 0 0 0-4.134 0l-.622.638-.89-.011a2.89 2.89 0 0 0-2.924 2.924l.01.89-.636.622a2.89 2.89 0 0 0 0 4.134l.637.622-.011.89a2.89 2.89 0 0 0 2.924 2.924l.89-.01.622.636a2.89 2.89 0 0 0 4.134 0l.622-.637.89.011a2.89 2.89 0 0 0 2.924-2.924l-.01-.89.636-.622a2.89 2.89 0 0 0 0-4.134l-.637-.622.011-.89a2.89 2.89 0 0 0-2.924-2.924l-.89.01-.622-.636zm.287 5.984-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.793l2.646-2.647a.5.5 0 0 1 .708.708z" />
                                </svg>
                            </span>
                            To promote the harmonious working relationship between the mining companies and the host communities.
                        </li>
                    </ul>
                    <a href="/about"
                        class="px-4 py-3 text-green-700 transition-all transform border border-green-500 hover:bg-green-600 dark:border-green-400 dark:hover:bg-green-500 dark:hover:text-gray-100 dark:hover:border-green-500 dark:text-green-400 hover:text-gray-100">
                        Read more
                    </a>
                </div>
            </div>
        </div>
    </section>
    <body class="flex min-h-screen flex-col justify-center">
    <div class="w-full">
      <div class="container mx-auto my-32 flex flex-col items-center gap-16">
        <div class="flex flex-col gap-16">
          <div class="flex flex-col gap-2 text-center">
            <h2
              class="mb-2 text-3xl font-extrabold leading-tight text-dark-grey-900 lg:text-4xl"
            >
              How it works?
            </h2>
            <p class="text-base font-medium leading-7 text-dark-grey-600">
              A Step-by-Step Guide
            </p>
          </div>
        </div>
        <div
          class="flex w-full flex-col items-center justify-between gap-y-10 lg:flex-row lg:gap-x-8 lg:gap-y-0 xl:gap-x-10"
        >
          <div class="flex items-start gap-4">
            <div
            class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 border-solid border-purple-blue-500 bg-transparent text-purple-blue-500"
            >
              <span class="text-base font-bold leading-7 ">1</span>
            </div>
            <div class="flex flex-col">
              <h3
                class="mb-2 text-base font-bold leading-tight text-dark-grey-900"
              >
                Create your Account
              </h3>
              <p class="text-base font-medium leading-7 text-dark-grey-600">
                Click on the Register button and provide all the required info.
              </p>
            </div>
          </div>
          <div class="rotate-90 lg:rotate-0">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="43"
              height="42"
              viewBox="0 0 43 42"
              fill="none"
            >
              <g clip-path="url(#clip0_3346_6663)">
                <path
                  d="M16.9242 11.7425C16.2417 12.425 16.2417 13.5275 16.9242 14.21L23.7142 21L16.9242 27.79C16.2417 28.4725 16.2417 29.575 16.9242 30.2575C17.6067 30.94 18.7092 30.94 19.3917 30.2575L27.4242 22.225C28.1067 21.5425 28.1067 20.44 27.4242 19.7575L19.3917 11.725C18.7267 11.06 17.6067 11.06 16.9242 11.7425Z"
                  fill="#68769F"
                />
              </g>
              <defs>
                <clipPath id="clip0_3346_6663">
                  <rect
                    width="42"
                    height="42"
                    fill="white"
                    transform="translate(0.666748)"
                  />
                </clipPath>
              </defs>
            </svg>
          </div>
          <div class="flex items-start gap-4">
            <div
              class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 border-solid border-purple-blue-500 bg-transparent text-purple-blue-500"
            >
              <span class="text-base font-bold leading-7">2</span>
            </div>
            <div class="flex flex-col">
              <h3
                class="mb-2 text-base font-bold leading-tight text-dark-grey-900"
              >
                Add All your Licenses
              </h3>
              <p class="text-base font-medium leading-7 text-dark-grey-600">
                After logging in, click on Add License to add your Licenses.
              </p>
            </div>
          </div>
          <div class="rotate-90 lg:rotate-0">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="43"
              height="42"
              viewBox="0 0 43 42"
              fill="none"
            >
              <g clip-path="url(#clip0_3346_6663)">
                <path
                  d="M16.9242 11.7425C16.2417 12.425 16.2417 13.5275 16.9242 14.21L23.7142 21L16.9242 27.79C16.2417 28.4725 16.2417 29.575 16.9242 30.2575C17.6067 30.94 18.7092 30.94 19.3917 30.2575L27.4242 22.225C28.1067 21.5425 28.1067 20.44 27.4242 19.7575L19.3917 11.725C18.7267 11.06 17.6067 11.06 16.9242 11.7425Z"
                  fill="#68769F"
                />
              </g>
              <defs>
                <clipPath id="clip0_3346_6663">
                  <rect
                    width="42"
                    height="42"
                    fill="white"
                    transform="translate(0.666748)"
                  />
                </clipPath>
              </defs>
            </svg>
          </div>
          <div class="flex items-start gap-4">
            <div
              class="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border-2 border-solid border-purple-blue-500 bg-transparent text-purple-blue-500"
            >
              <span class="text-base font-bold leading-7">3</span>
            </div>
            <div class="flex flex-col">
              <h3
                class="mb-2 text-base font-bold leading-tight text-dark-grey-900"
              >
                Upload License Documents
              </h3>
              <p class="text-base font-medium leading-7 text-dark-grey-600">
                Upload all necessary documents and submit for Approval
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>

        </main>

        <!-- Footer -->
            <Footer />
       <!-- End of Footer -->
    </div>
</template>

<script setup>

import Header from "../components/Header.vue";
import Footer from "../components/Footer.vue";
import {ref} from "vue";

const mobileMenuOpen = ref(false)
</script>

<style scoped>

</style>
